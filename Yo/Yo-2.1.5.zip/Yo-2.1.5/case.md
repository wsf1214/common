## 基于 Yo 构建的网站

越来越多的移动Web应用基于 Yo 来构建。你可以先参观一下我们提供的 [实例代码](../demo/index.html) 或者看一看使用 Yo 构建的案例。

* ![去哪儿网](http://source.qunarzz.com/common/hf/logo.png)

    在去哪儿网已有“近百个”移动Web应用基于 Yo 来构建

* ![Amily](http://www.doyoe.com/pimg/amily.png)

    北京美至网络科技有限公司大部分移动Web应用均基于 Yo 构建

* ![本木医疗](http://www.doyoe.com/pimg/benmu.png)

    本木医疗已接入使用 Yo 框架来构建移动应用UI

* ![积木盒子](http://www.doyoe.com/pimg/jimu.png)

    积木盒子已接入使用 Yo 框架来构建移动应用UI

* ![医联](http://www.doyoe.com/pimg/medlinker.png)

    医联已接入使用 Yo 框架来构建移动应用UI

* ![百家互联](http://www.doyoe.com/pimg/genshuixue.png)

    百家互联（跟谁学）已接入使用 Yo 框架来构建移动应用UI